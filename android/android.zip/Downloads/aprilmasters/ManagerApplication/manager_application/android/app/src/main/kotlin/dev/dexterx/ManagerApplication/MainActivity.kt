package dev.dexterx.ManagerApplication
import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}
